# Kit institucional · 8 plantillas de trabajo

Aprendamos de Criptomonedas · aprendamosdecriptomonedas.lat · v1.0 · noviembre 2026

Gratis. Sin registro y sin dependencias: todo son archivos locales.

## Qué hay dentro

| Carpeta | Contenido |
| --- | --- |
| 01_PDF | Una guía A4 por plantilla: portada, cómo se usa, esquema de columnas y hoja de trabajo imprimible. |
| 02_EXCEL | El archivo para operar: fórmulas, listas desplegables, filtros y formato condicional. |
| 03_CSV | Los mismos datos en texto plano (UTF-8, separador «;») para importar donde quieras. |
| 03_CSV/diccionario-de-datos.csv | Campo, etiqueta, definición y ejemplo de cada columna. |

Abre `index.html` con doble clic para ver el kit como una página, sin conexión.

## Las 8 plantillas

1. **Plantilla de análisis de wallet** — Analiza la antigüedad, la actividad, la concentración de activos y los envíos a exchanges de una wallet.
2. **Plantilla de métricas de red** — Analiza la capitalización de mercado, la valoración totalmente diluida (FDV), el volumen negociado y los próximos desbloqueos de un token.
3. **Checklist de seguridad institucional** — Doce controles para revisar la custodia, las frases de recuperación, las hardware wallets y las operaciones.
4. **Registro de operaciones (trading log)** — Registra cada compra y venta, el nivel de stop-loss y el motivo de cada decisión.
5. **Inventario de billeteras y almacenamiento en frío** — Registra cuánto capital tienes en exchanges y cuánto mantienes bajo tu propia custodia.
6. **Calculadora del tamaño de posición** — Calcula el tamaño de una posición según el capital, el riesgo aceptado por operación y la distancia al stop-loss.
7. **Plantilla de tesis de inversión e invalidación** — Documenta la tesis fundamental, las métricas de adopción, los catalizadores y el precio o evento que la invalidaría.
8. **Seguimiento de airdrops y puntos** — Registra los puntos acumulados, el gasto en gas, las transacciones y las billeteras asociadas a protocolos que aún no han lanzado su token.

## Cómo se usa

1. Empieza por el PDF, que explica qué mide cada campo antes de que escribas.
2. Pasa al Excel: la hoja «Empieza aquí» tiene las instrucciones y la hoja «Plantilla» ya trae fórmulas y listas.
3. Elimina la fila de ejemplo cuando entiendas la estructura. Contiene datos de muestra, no datos de mercado.
4. Para importar el CSV en Excel, ve a «Datos > Desde texto» y selecciona «;» como separador.

## Qué no es

No es asesoría financiera ni una recomendación de compra. Los umbrales y ejemplos tienen fines
ilustrativos; verifica tus datos en cadena. En el sitio, el bloque de formación es un enlace de
afiliado y está señalado como tal.

## Licencia de uso

Uso libre para tu operación personal o de tu negocio. No revendas los archivos como producto
propio ni retires la marca: si los compartes, comparte el enlace original.
