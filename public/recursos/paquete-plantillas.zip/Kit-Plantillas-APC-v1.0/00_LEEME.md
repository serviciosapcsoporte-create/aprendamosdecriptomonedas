# Kit institucional · 8 plantillas de trabajo

Aprendamos de Criptomonedas · aprendamosdecriptomonedas.lat · v1.0 · noviembre 2026

Gratis. Sin registro y sin dependencias: todo son archivos locales.

## Qué hay dentro

| Carpeta | Contenido |
| --- | --- |
| 01_PDF | Una guía A4 por plantilla: portada, cómo se usa, esquema de columnas y hoja de trabajo imprimible. |
| 02_EXCEL | El archivo para operar: fórmulas, listas desplegables, filtros y formato condicional. |
| 03_CSV | Los mismos datos en texto plano (UTF-8, separador «;») para importar donde quieras. |
| 03_CSV/diccionario-de-datos.csv | Campo, etiqueta, definición y ejemplo de cada columna. |

Abre `index.html` con doble clic para ver el kit como una página, sin conexión.

## Las 8 plantillas

1. **Plantilla de AnÃ¡lisis de Wallet** — CÃ³mo auditar una wallet: antigÃ¼edad, cadencia de transacciones, concentraciÃ³n de activos y envÃ­os hacia exchanges.
2. **Plantilla de MÃ©tricas de Red** — Los ratios que separan un proyecto sÃ³lido de una preventa: FDV/MCap, rotaciÃ³n y calendarios de desbloqueo.
3. **Checklist de Seguridad Institucional** — 12 puntos verificables en diez minutos sobre custodia, frases de recuperaciÃ³n, hardware wallets y firmas operativas.
4. **Registro de Operaciones & Trading Log** — Lleva el registro estricto de cada compra, venta, nivel de stop-loss y la justificaciÃ³n tÃ¡ctica de tu decisiÃ³n.
5. **Inventario de Wallets & Cold Storage** — Control de balance real: audita cuÃ¡nto capital tienes depositado en exchanges y cuÃ¡nto controlas bajo custodia propia.
6. **Calculadora de PosiciÃ³n & Risk Sizing** — TamaÃ±o exacto de la posiciÃ³n segÃºn capital total, tolerancia al riesgo por operaciÃ³n y distancia al stop-loss.
7. **Plantilla de Tesis de InversiÃ³n & InvalidaciÃ³n** — Documenta la tesis fundamental, mÃ©tricas de adopciÃ³n, catalizadores y el precio o evento exacto que invalida la tesis.
8. **Seguimiento de Airdrops & Points Farming** — Controla puntos acumulados, gas invertido, nÃºmero de transacciones y carteras en protocolos pre-token.

## Cómo se usa

1. Empieza por el PDF: explica qué mide cada campo antes de que escribas nada.
2. Pasa al Excel: la hoja «Empieza aquí» tiene las instrucciones y la hoja «Plantilla» ya trae fórmulas y listas.
3. Borra la fila de ejemplo cuando entiendas la estructura. Esos números son de muestra, no de mercado.
4. El CSV es para importar a otra herramienta; si lo abres en Excel usa «Datos > Desde texto» y elige «;» como separador.

## Qué no es

No es asesoría financiera ni una recomendación de compra. Los umbrales y ejemplos son de
referencia editorial; la verificación de tus datos on-chain es tuya. En el sitio, el bloque de
formación es un enlace de afiliado y está señalado como tal.

## Licencia de uso

Uso libre para tu operación personal o de tu negocio. No revendas los archivos como producto
propio ni retires la marca: si los compartes, comparte el enlace original.
