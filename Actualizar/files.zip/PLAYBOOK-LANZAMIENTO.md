# Playbook de Lanzamiento — Aprendamos de Criptomonedas

Guía paso a paso, día por día. Cada día trae un **prompt listo para copiar y pegar**
en Claude Code, Cursor, o cualquier asistente de IA con acceso a tu repositorio.
Si un paso no requiere código, te doy las instrucciones directas.

**Antes de empezar:** descarga y descomprime `fix-bugs-tecnicos.zip` (te lo compartí
antes). Ya contiene todos los archivos corregidos y funcionando (validé el build).

---

## ✅ Ya resuelto (no repitas esto)

- Íconos rotos en Nivel 1-2
- Rutas duplicadas en Nivel 1
- Badges (free/register/paid) corregidos en todos los niveles
- Errores de redacción y typos en Nivel 3, 4 y 5
- Dato desactualizado sobre impuestos en Portugal
- `MainNav.tsx` unificado (ya no hay menú duplicado)
- **Bug crítico de negocio:** la insignia de cada lección estaba hardcodeada a "GRATIS" en Nivel 3-5, sin importar el badge real — corregido
- **Bloqueo de contenido real:** Nivel 3-5 ahora muestran solo el primer párrafo + botón de desbloqueo (antes se mostraba el 100% del contenido a cualquiera, sin importar el badge)

---

## DÍA 1 — Aplicar los archivos corregidos a tu repo real

### Instrucciones directas (sin IA)
1. Clona tu repo si no lo tienes local:
   ```bash
   git clone https://github.com/serviciosapcsoporte-create/aprendamosdecriptomonedas.git
   cd aprendamosdecriptomonedas
   ```
2. Descomprime `fix-bugs-tecnicos.zip` en una carpeta aparte.
3. Copia cada archivo a su misma ruta dentro del repo (sobrescribiendo):
   - `TopicIcon.tsx` → `app/components/TopicIcon.tsx`
   - `TopicGate.tsx` → `app/components/TopicGate.tsx`
   - `access-links.ts` → `app/data/access-links.ts`
   - `MainNav.tsx` → `app/components/MainNav.tsx`
   - `curriculum.ts`, `level3.ts`, `level4.ts`, `level5.ts` → `app/data/`
   - `nivel-1/$topicSlug.tsx` ... `nivel-5/$topicSlug.tsx` → `app/routes/nivel-X/$topicSlug.tsx`
4. **Elimina** (ya no existen en la versión corregida, deben borrarse del repo):
   - `app/routes/nivel-1/que-es-blockchain.tsx`
   - `app/routes/nivel-1/como-funciona-un-bloque.tsx`

### Prompt para Claude Code (si prefieres que la IA lo haga)
```
Tengo una carpeta llamada "fix-bugs-tecnicos" con archivos corregidos que debo
aplicar a este repositorio. Haz lo siguiente:

1. Copia cada archivo de fix-bugs-tecnicos/ a su ruta equivalente dentro de app/,
   sobrescribiendo el original (usa la misma estructura de carpetas: TopicIcon.tsx
   va a app/components/, level3.ts va a app/data/, nivel-1/$topicSlug.tsx va a
   app/routes/nivel-1/$topicSlug.tsx, etc.)
2. Elimina estos dos archivos que ya no deben existir:
   - app/routes/nivel-1/que-es-blockchain.tsx
   - app/routes/nivel-1/como-funciona-un-bloque.tsx
3. Ejecuta `npm install` y luego `npm run build` para confirmar que todo compila
   sin errores.
4. Ejecuta `npm run typecheck` y dime si aparece algún error NUEVO (ignora errores
   preexistentes en app/routes/recursos/ o routeTree.gen, esos son de otra parte
   del proyecto).
5. Muéstrame un resumen de qué archivos cambiaron con `git status` y `git diff --stat`.

No hagas commit ni push todavía, solo aplica los cambios y valida que compile.
```

---

## DÍA 2 — Revisar el resultado localmente antes de publicar

### Prompt
```
Levanta el servidor de desarrollo con `npm run dev` y dime en qué puerto quedó
corriendo. Luego revisa que las siguientes rutas existan y no den error 404,
listando su contenido resumido (primeras líneas del HTML renderizado o del
componente):

- /nivel-1-principiante
- /nivel-1/que-es-blockchain
- /nivel-3-avanzado
- /nivel-3/dex-vs-exchange-centralizado
- /nivel-4-experto
- /nivel-5-especializaciones

Confirma también que en las rutas de Nivel 3, 4 y 5 el componente TopicContent
esté mostrando la tarjeta de bloqueo (candado + botón), y que en Nivel 1 y 2 se
muestre el contenido completo sin bloqueo.
```

Revisa tú mismo en el navegador entrando a `http://localhost:3000` (o el puerto
que indique). Fíjate especialmente en:
- Que los íconos ya no digan "lock", "hash", etc. como texto — deben verse como íconos reales.
- Que al entrar a una lección de Nivel 3-5 veas el candado con el botón de desbloqueo.
- Que el menú superior muestre "Registro" en Nivel 3 y "Premium" en Nivel 4 y 5 (ya no "Gratis").

---

## DÍA 3 — Crear los productos en Payhip (esto lo haces tú, no la IA)

Payhip no se puede automatizar desde aquí porque requiere tu cuenta y tus datos
de cobro. Sigue estos pasos manualmente en [payhip.com](https://payhip.com):

1. **Crea tu cuenta** en Payhip si no la tienes, y conecta tu método de cobro
   (Stripe o PayPal) en Settings → Payment Gateways.
2. **Producto Nivel 3 (registro, precio $0 o simbólico):**
   - Nuevo producto → tipo "Digital Download" o "Membership"
   - Precio: $0 (o el precio accesible que definiste, ej. $5-$15)
   - Sube el contenido del Nivel 3 en PDF (puedes generarlo pidiéndole a la IA
     que compile `level3.ts` en un PDF — ver prompt abajo)
   - Copia la URL del producto (formato `https://payhip.com/b/XXXXX`)
3. **Producto Nivel 4:** repite el proceso, precio $20-$40 sugerido.
4. **Producto Nivel 5:** repite el proceso, precio $50-$100+ sugerido.
5. Guarda las 3 URLs — las necesitas en el Día 4.

### Prompt para generar los PDFs de cada nivel (para subir a Payhip)
```
Necesito compilar el contenido de app/data/level3.ts (y luego level4.ts,
level5.ts por separado) en un documento PDF profesional para vender en Payhip.

Para cada nivel:
1. Extrae el campo `title` y `content` de cada tema en el archivo.
2. Genera un PDF con: portada (título del nivel), tabla de contenidos, y cada
   lección con su título como encabezado y su contenido debajo, respetando el
   formato markdown (negritas, listas, tablas).
3. Usa el skill de PDF disponible para que quede con diseño profesional, no
   texto plano.
4. Guarda el resultado como nivel-3-completo.pdf, nivel-4-completo.pdf y
   nivel-5-completo.pdf.

Hazlo un nivel a la vez para revisar cada uno antes de continuar con el siguiente.
```

---

## DÍA 4 — Conectar las URLs reales de Payhip al sitio

### Prompt
```
Ya tengo las URLs reales de mis 3 productos en Payhip. Actualiza el archivo
app/data/access-links.ts reemplazando los placeholders:

- accessLinks.register.url → [PEGA AQUÍ TU URL DEL NIVEL 3]
- accessLinks.paid.url → [PEGA AQUÍ TU URL DE NIVEL 4/5, O CREA DOS ENTRADAS
  SEPARADAS SI QUIERES DISTINGUIR NIVEL 4 DE NIVEL 5]

Si quiero URLs distintas para Nivel 4 y Nivel 5 (no la misma), modifica también
TopicGate.tsx para que accessLinks tenga claves "paid-4" y "paid-5" en vez de
una sola "paid", y que TopicContent elija la correcta según topic.level.

Después de editar, corre `npm run build` para confirmar que compila.
```

---

## DÍA 5 — Publicar (push a GitHub → deploy automático)

Tu sitio se despliega solo vía GitHub Actions cada vez que haces push a `main`
(ya está configurado en `.github/workflows/deploy.yml`). No necesitas hacer nada
manual de hosting.

### Prompt
```
Todo compila bien localmente. Ahora:

1. Ejecuta `npm run lint` y arregla cualquier error si aparece.
2. Haz commit de todos los cambios con un mensaje claro, por ejemplo:
   "fix: corrige iconos, badges, contenido de niveles 3-5 y agrega bloqueo de
   acceso real con enlaces a Payhip"
3. Haz push a la rama main.
4. Dime exactamente qué comandos usaste y confírmame que el push fue exitoso.

No hagas push si `npm run build` falla — en ese caso dime el error primero.
```

Después del push, ve a la pestaña **Actions** de tu repo en GitHub y espera a que
el workflow "Deploy a GitHub Pages" termine en verde (toma 1-3 minutos). Luego
entra a `https://aprendamosdecriptomonedas.lat` y verifica en producción.

---

## DÍA 6 — Checklist de pruebas en producción

Revisa esto manualmente en el sitio ya publicado (no requiere IA, son 10 minutos):

- [ ] La home carga y los 5 niveles se ven con su badge correcto (Gratis/Registro/Premium)
- [ ] Una lección de Nivel 1 se abre completa, sin bloqueo
- [ ] Una lección de Nivel 3 muestra el primer párrafo + botón "Regístrate gratis..."
- [ ] El botón de Nivel 3 lleva a tu producto correcto en Payhip
- [ ] Una lección de Nivel 4 y una de Nivel 5 muestran el botón "Desbloquea..." con el link correcto
- [ ] Los íconos de cada lección se ven como íconos (no como texto "lock", "hash", etc.)
- [ ] El menú de navegación despliega correctamente los 5 niveles con sus temas
- [ ] Compra de prueba en Payhip (usa modo test de Stripe si está disponible) para confirmar que el flujo de pago funciona de punta a punta

---

## DÍA 7 — Pendiente de arquitectura (opcional, cuando quieras subir de nivel)

Esto no es urgente para lanzar, pero es importante que lo sepas:

**El bloqueo actual es "soft" (de fricción), no a prueba de balas.** Como el sitio
es 100% estático (GitHub Pages, sin backend/servidor), el contenido completo de
Nivel 3-5 sigue viajando dentro del archivo JavaScript que se descarga en el
navegador — alguien con conocimientos técnicos podría leerlo con las herramientas
de desarrollador sin pagar. Para el 99% de tus visitantes esto nunca será un
problema (nadie va a hacer eso), pero es honesto que lo sepas.

Si en el futuro quieres un bloqueo real:
```
Quiero implementar un bloqueo de contenido real (no solo visual) para Nivel 3-5.
Investiga la opción de mover el contenido completo de esos niveles fuera del
bundle público — por ejemplo, sirviendo el contenido vía una función serverless
(Cloudflare Workers o Vercel Functions) que verifique un token de compra de
Payhip antes de devolver el texto completo. Dame un plan de migración desde
GitHub Pages hacia esa arquitectura, con los pasos y el costo aproximado.
```

Por ahora, con el bloqueo visual + los 3 productos en Payhip, tu embudo de
negocio ya funciona de principio a fin.
